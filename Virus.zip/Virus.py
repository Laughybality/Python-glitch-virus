import pygame
import os

# Initialize Pygame
pygame.init()

# Set up the display
WIDTH, HEIGHT = 225, 215
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Background Image")
pygame.display.toggle_fullscreen()

# Load background image
current_path = os.path.dirname(__file__)  # Get the directory of the script
background_image = pygame.image.load(os.path.join(current_path, "background.jpg")).convert()

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Draw background image
    screen.blit(background_image, (0, 0))

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
